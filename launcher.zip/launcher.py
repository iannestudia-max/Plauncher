#!/usr/bin/env python3
"""
launcher_updater.py
Launcher + Updater fusionado con dark theme real y comportamiento:
- aplica actualizaciones (añade/actualiza archivos nuevos del paquete)
- no borra archivos locales que no vengan en el update
- no toca la carpeta 'versions'
- si viene un nuevo ejecutable, lo coloca como <exe>.new para aplicar al reinicio
"""

import os
import sys
import re
import threading
import time
import shutil
import zipfile
import subprocess
from pathlib import Path
from urllib.parse import urlparse, parse_qs

import ssl
# Nota: en entornos extraños de TLS/SSL compilados puede dar problemas.
# La siguiente línea evita errores con algunos builds; si prefieres validar certificados,
# coméntala.
ssl._create_default_https_context = ssl._create_unverified_context

import requests
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# ================= CONFIG =================
PASTEBIN_URL = "https://pastebin.com/raw/253RbBf9"  # formato: version | zip_url
APP_NAME = "TurboWarp Launcher"
# =========================================

# -------- PATHS (UNA SOLA BASE) ----------
# Detectar correctamente entornos:
# - Si estamos en un bundle tipo PyInstaller, puede existir sys._MEIPASS
# - Si estamos frozen (Nuitka, pyinstaller onefile) usaremos sys.executable.parent
# - En dev usar __file__
if hasattr(sys, "_MEIPASS"):
    # recursos empaquetados (PyInstaller-style)
    BASE = Path(sys._MEIPASS)
elif getattr(sys, "frozen", False):
    # ejecutable ya desplegado: usar carpeta del exe para lecturas y especialmente para escrituras
    BASE = Path(sys.executable).parent
else:
    BASE = Path(__file__).parent.resolve()

# Para lecturas desde paquete podemos usar PACKAGE_BASE (igual que BASE),
# pero para seguridad de escritura usamos WRITE_BASE (si estamos frozen, es la carpeta del exe).
WRITE_BASE = Path(sys.executable).parent if getattr(sys, "frozen", False) else BASE

VERL = WRITE_BASE / "verl.txt"
VERX = WRITE_BASE / "verx.txt"
VERSIONS = WRITE_BASE / "versions"
TEMP = WRITE_BASE / "temp"
TURBOPATH = WRITE_BASE / "turbowarp_path.txt"

# Asegurar directorios/archivos (se crean en WRITE_BASE, que es escribible)
VERSIONS.mkdir(parents=True, exist_ok=True)
TEMP.mkdir(parents=True, exist_ok=True)

# Asegurar archivos importantes (si no existen, se crean vacíos o con valor por defecto)
def ensure_file(p: Path, default=""):
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text(default, encoding="utf-8")

ensure_file(VERL, "0.0.0")
ensure_file(VERX, "")
ensure_file(TURBOPATH, "")

# ----------------------------------------

# ---------- THEME COLORS (dark) ----------
COL_BG = "#0b0b0b"
COL_FRAME = "#111213"
COL_FG = "#e6e6e6"
COL_ACCENT = "#3aff7a"
COL_BTN = "#1f1f1f"
COL_ENTRY = "#0f1112"
COL_SELECT = "#334e3a"
# -----------------------------------------

# ---------- UTILS ----------
def read_verl():
    ensure_file(VERL, "0.0.0")
    return VERL.read_text().strip()

def write_verl(v: str):
    ensure_file(VERL)
    VERL.write_text(v, encoding="utf-8")

def normalize_paste(url: str) -> str:
    if "pastebin.com" in url and "/raw/" not in url:
        key = urlparse(url).path.strip("/")
        return f"https://pastebin.com/raw/{key}"
    return url

def parse_paste(txt: str):
    for l in txt.splitlines():
        s = l.strip()
        if not s:
            continue
        if "|" in s:
            v, u = s.split("|", 1)
            return v.strip(), u.strip()
    raise ValueError("Formato inválido en pastebin")

def sanitize_filename(name: str) -> str:
    return re.sub(r'[^A-Za-z0-9_.-]', '_', name)

# ---------- URL RESOLVE ----------
def resolve_mediafire(url: str) -> str:
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    m = re.search(r'https?://download[^"\']+', r.text)
    if not m:
        raise Exception("MediaFire no resolvió link directo")
    return m.group(0)

def resolve_gdrive(url: str) -> str:
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)
    fid = qs.get("id", [None])[0]
    if not fid:
        # try /d/ID/
        m = re.search(r'/file/d/([a-zA-Z0-9_-]+)', url)
        if m:
            fid = m.group(1)
    if not fid:
        raise Exception("No se pudo extraer ID de Google Drive.")
    return f"https://drive.google.com/uc?export=download&id={fid}"

def resolve_url(url: str) -> str:
    u = url.lower()
    if "mediafire.com" in u:
        return resolve_mediafire(url)
    if "drive.google.com" in u or "docs.google.com" in u:
        return resolve_gdrive(url)
    return url

# ---------- UPDATE APPLY (añade/actualiza archivos NUEVOS si faltan) ----------
def apply_update(zip_url: str, new_version: str, gui):
    gui.set_status("Descargando actualización...")
    zip_path = TEMP / "update.zip"
    direct = resolve_url(zip_url)

    # descarga con progreso
    with requests.get(direct, stream=True) as r:
        r.raise_for_status()
        total_hdr = r.headers.get("content-length")
        total = int(total_hdr) if total_hdr and total_hdr.isdigit() else 0
        downloaded = 0
        with open(zip_path, "wb") as f:
            for chunk in r.iter_content(8192):
                if not chunk:
                    continue
                f.write(chunk)
                downloaded += len(chunk)
                if total:
                    perc = int(downloaded * 100 / total)
                    gui.progress['value'] = perc
                    gui.set_status(f"Descargando... {perc}% ({downloaded}/{total} bytes)")
                else:
                    gui.progress.start(10)
                    gui.set_status(f"Descargando... {downloaded} bytes")

    gui.progress.stop()
    gui.set_status("Extrayendo actualización...")
    ext = TEMP / "ext"
    if ext.exists():
        shutil.rmtree(ext)
    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(ext)

    gui.set_status("Instalando archivos (añadiendo/actualizando)...")
    exe_name = Path(sys.executable).name if getattr(sys, "frozen", False) else Path(__file__).name
    new_installed = []
    updated_installed = []

    for root, _, files in os.walk(ext):
        root = Path(root)
        for f in files:
            src = root / f
            rel = src.relative_to(ext)
            # no tocar versions/
            if rel.parts and rel.parts[0].lower() == "versions":
                continue
            # instalar en WRITE_BASE (carpeta del exe cuando está frozen) para que sea escribible
            dst = WRITE_BASE / rel

            # si viene un exe que coincide con el actual cuando está frozen:
            if getattr(sys, "frozen", False) and f == exe_name:
                # write as exe_name.new (no borrar el exe en ejecución)
                dst = WRITE_BASE / (exe_name + ".new")

            dst.parent.mkdir(parents=True, exist_ok=True)

            if not dst.exists():
                shutil.copy2(src, dst)
                new_installed.append(str(rel))
            else:
                # Overwrite existing file (actualiza)
                shutil.copy2(src, dst)
                updated_installed.append(str(rel))

    # escribir nueva versión
    write_verl(new_version)

    # mostrar resumen
    summary = []
    if new_installed:
        summary.append("Archivos nuevos instalados:\n" + "\n".join(new_installed))
    if updated_installed:
        summary.append("Archivos actualizados:\n" + "\n".join(updated_installed))
    if not summary:
        summary_text = "Actualización aplicada (sin archivos nuevos)."
    else:
        summary_text = "\n\n".join(summary)

    gui.set_status("Actualización aplicada.")
    messagebox.showinfo("Actualizado", f"Versión {new_version} aplicada.\n\n{summary_text}\n\nSi se reemplazó el ejecutable, reinicia para completar.")
    # Si aplicamos cambios al ejecutable, pedimos reinicio/exit para que el proceso .new sea renombrado en el arranque
    gui.root.quit()

# ---------- THEME / GUI HELPERS ----------
def apply_dark_theme(root):
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass

    style.configure("TFrame", background=COL_FRAME)
    style.configure("TLabel", background=COL_FRAME, foreground=COL_FG, font=("Segoe UI", 10))
    style.configure("Header.TLabel", font=("Segoe UI", 14, "bold"), foreground=COL_FG, background=COL_FRAME)
    style.configure("TButton", background=COL_BTN, foreground=COL_FG, relief="flat", padding=6)
    style.map("TButton",
              background=[("active", "#2a2a2a"), ("!disabled", COL_BTN)])
    style.configure("TEntry", fieldbackground=COL_ENTRY, foreground=COL_FG)
    style.configure("Horizontal.TProgressbar", troughcolor=COL_FRAME, background=COL_ACCENT)

    # root bg
    root.configure(bg=COL_BG)

# ---------- LAUNCHER APP ----------
class LauncherApp:
    def __init__(self, root):
        self.root = root
        root.title(APP_NAME)
        root.geometry("700x480")
        root.resizable(False, False)

        apply_dark_theme(root)

        main = ttk.Frame(root, padding=12)
        main.pack(fill="both", expand=True)

        ttk.Label(main, text=APP_NAME, style="Header.TLabel").pack(anchor="w")

        top_frame = ttk.Frame(main)
        top_frame.pack(fill="both", expand=True, pady=(8,6))

        # listbox + scrollbar
        lb_frame = tk.Frame(top_frame, bg=COL_FRAME)
        lb_frame.pack(fill="both", expand=True)
        self.listbox = tk.Listbox(lb_frame, bg=COL_ENTRY, fg=COL_FG, selectbackground=COL_SELECT,
                                  selectforeground=COL_FG, bd=0, highlightthickness=0, font=("Segoe UI", 10))
        self.listbox.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(lb_frame, orient="vertical", command=self.listbox.yview)
        scrollbar.pack(side="right", fill="y")
        self.listbox.config(yscrollcommand=scrollbar.set)
        self.listbox.bind("<<ListboxSelect>>", lambda e: self.on_select())

        # progress + status
        self.progress = ttk.Progressbar(main, length=660, style="Horizontal.TProgressbar")
        self.progress.pack(pady=(10,6))
        self.status_label = ttk.Label(main, text="Listo.")
        self.status_label.pack(anchor="w")

        # buttons
        btn_frame = ttk.Frame(main)
        btn_frame.pack(fill="x", pady=(8,0))
        ttk.Button(btn_frame, text="Descargar", command=self.on_download).pack(side="left", padx=6)
        ttk.Button(btn_frame, text="Lanzar", command=self.on_launch).pack(side="left", padx=6)
        ttk.Button(btn_frame, text="Eliminar local", command=self.on_delete).pack(side="left", padx=6)
        ttk.Button(btn_frame, text="Config TurboWarp", command=self.on_config).pack(side="left", padx=6)
        ttk.Button(btn_frame, text="Forzar check update", command=lambda: threading.Thread(target=self.check_update, daemon=True).start()).pack(side="right", padx=6)

        self.versions = []
        self._download_lock = threading.Lock()

        self.reload_versions()

        # check updates in background
        threading.Thread(target=self.check_update, daemon=True).start()

    def set_status(self, text: str):
        self.status_label.config(text=text)
        self.root.update_idletasks()

    def reload_versions(self):
        self.versions = []
        self.listbox.delete(0, tk.END)
        if not VERX.exists():
            self.set_status("verx.txt no encontrado.")
            return
        for line in VERX.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if not s:
                continue
            if "|" in s:
                n, u = s.split("|", 1)
                n = n.strip()
                u = u.strip()
                mark = "✓" if (VERSIONS / (sanitize_filename(n) + ".sb3")).exists() else " "
                self.versions.append((n, u))
                self.listbox.insert(tk.END, f"[{mark}] {n}  —  {u}")
        self.set_status("Lista recargada.")

    def get_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            return None
        idx = sel[0]
        if idx < 0 or idx >= len(self.versions):
            return None
        return self.versions[idx]

    def on_select(self):
        sel = self.get_selected()
        if not sel:
            self.set_status("Seleccione una versión.")
            return
        name, url = sel
        p = VERSIONS / (sanitize_filename(name) + ".sb3")
        if p.exists():
            self.set_status(f"{name} -> listo localmente ({p.name})")
        else:
            self.set_status(f"{name} -> no descargado")

    def on_download(self):
        sel = self.get_selected()
        if not sel:
            messagebox.showinfo("Info", "Selecciona una versión primero.")
            return
        threading.Thread(target=self._download_thread, args=(sel,), daemon=True).start()

    def _download_thread(self, sel):
        with self._download_lock:
            name, url = sel
            tmp = VERSIONS / (sanitize_filename(name) + ".sb3.part")
            final = VERSIONS / (sanitize_filename(name) + ".sb3")
            if tmp.exists():
                try:
                    tmp.unlink()
                except Exception:
                    pass
            session = requests.Session()
            try:
                self.set_status(f"Resolviendo enlace para {name}...")
                resolved = resolve_url(url)
            except Exception as e:
                self.set_status("Error resolviendo enlace")
                messagebox.showerror("Error", f"No se pudo resolver enlace: {e}")
                return
            try:
                self.set_status(f"Descargando {name}...")
                with session.get(resolved, stream=True, allow_redirects=True, timeout=30) as r:
                    r.raise_for_status()
                    total_hdr = r.headers.get("content-length")
                    total = int(total_hdr) if total_hdr and total_hdr.isdigit() else 0
                    downloaded = 0
                    with open(tmp, "wb") as f:
                        for chunk in r.iter_content(8192):
                            if not chunk:
                                continue
                            f.write(chunk)
                            downloaded += len(chunk)
                            if total:
                                perc = int(downloaded * 100 / total)
                                self.progress['value'] = perc
                                self.set_status(f"Descargando {name}: {perc}% ({downloaded}/{total} bytes)")
                            else:
                                self.progress.start(10)
                                self.set_status(f"Descargando {name}: {downloaded} bytes")
                self.progress.stop()
                # validate zip (sb3)
                if not zipfile.is_zipfile(tmp):
                    raise Exception("Archivo inválido (no es ZIP/SB3 válido).")
                if final.exists():
                    final.unlink()
                tmp.rename(final)
                self.set_status(f"Descargado: {final.name}")
                self.reload_versions()
            except Exception as e:
                self.progress.stop()
                self.set_status(f"Error en descarga: {e}")
                messagebox.showerror("Error", f"No se pudo descargar: {e}")

    def on_delete(self):
        sel = self.get_selected()
        if not sel:
            messagebox.showinfo("Info", "Selecciona una versión primero.")
            return
        name, _ = sel
        p = VERSIONS / (sanitize_filename(name) + ".sb3")
        if not p.exists():
            messagebox.showinfo("Info", "No existe el archivo local.")
            self.reload_versions()
            return
        if not messagebox.askyesno("Confirm", f"Eliminar {p.name}?"):
            return
        try:
            p.unlink()
            self.set_status(f"{p.name} eliminado.")
            self.reload_versions()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar: {e}")

    def on_config(self):
        cur = TURBOPATH.read_text(encoding="utf-8").strip() if TURBOPATH.exists() else ""
        if messagebox.askyesno("Config TurboWarp", "¿Seleccionar archivo TurboWarp.exe manualmente?"):
            path = filedialog.askopenfilename(title="Selecciona TurboWarp.exe",
                                              filetypes=[("Executables", "*.exe"), ("All files", "*.*")])
            if path:
                TURBOPATH.write_text(path, encoding="utf-8")
                messagebox.showinfo("Guardado", f"Ruta guardada: {path}")
        else:
            if cur and messagebox.askyesno("Eliminar", "¿Eliminar la ruta guardada actual?"):
                try:
                    TURBOPATH.unlink(missing_ok=True)
                    messagebox.showinfo("Eliminado", "Ruta guardada eliminada.")
                except Exception:
                    pass

    def on_launch(self):
        sel = self.get_selected()
        if not sel:
            messagebox.showinfo("Info", "Selecciona una versión primero.")
            return
        name, _ = sel
        p = VERSIONS / (sanitize_filename(name) + ".sb3")
        if not p.exists():
            if messagebox.askyesno("No descargado", "El archivo no está descargado. ¿Descargar ahora?"):
                self.on_download()
            return
        turbo = TURBOPATH.read_text(encoding="utf-8").strip() if TURBOPATH.exists() else None
        if turbo and Path(turbo).exists():
            try:
                subprocess.Popen([turbo, str(p)], cwd=str(WRITE_BASE))
                return
            except Exception:
                pass
        # fallback: abrir con asociación del SO
        try:
            if sys.platform.startswith("win"):
                os.startfile(p)
            elif sys.platform.startswith("darwin"):
                subprocess.Popen(["open", str(p)])
            else:
                subprocess.Popen(["xdg-open", str(p)])
        except Exception:
            messagebox.showerror("Error", "No se pudo abrir automáticamente. Configura TurboWarp en 'Config TurboWarp'.")

    # ---------- UPDATE CHECK ----------
    def check_update(self):
        try:
            local = read_verl()
            txt = requests.get(normalize_paste(PASTEBIN_URL), timeout=10).text
            remote, url = parse_paste(txt)
            if remote != local:
                if messagebox.askyesno("Actualización disponible", f"Hay nueva versión: {local} → {remote}\n¿Descargar e instalar?"):
                    apply_update(url, remote, self)
            else:
                self.set_status("No hay actualizaciones.")
        except Exception as e:
            self.set_status(f"Error check update: {e}")

# ---------- BOOT / SWAP .new exe ----------
def swap_new_exe_if_present():
    # Si existe <exe>.new, sustituir el exe actual (sólo aplicable cuando está frozen/ejecutable)
    if getattr(sys, "frozen", False):
        exe = Path(sys.executable)
        new = exe.with_name(exe.name + ".new")
        try:
            if new.exists():
                # intenta borrar exe actual y renombrar
                try:
                    exe.unlink()
                except Exception:
                    # no se pudo borrar (puede pasar en Windows si está en uso) -> esperar y reintentar
                    time.sleep(0.4)
                # renombrar (si sigue fallando, se ignorará y se intentará la próxima ejecución)
                try:
                    new.rename(exe)
                except Exception:
                    pass
        except Exception:
            # no crítico, se intentará nuevamente la próxima ejecución
            pass

# ---------- MAIN ----------
def main():
    swap_new_exe_if_present()

    root = tk.Tk()
    app = LauncherApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
