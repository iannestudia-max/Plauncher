#!/usr/bin/env python3
"""launcher_updater.py (corregido + panel de logs a la izquierda)

Cambios principales:
- Interfaz dividida horizontalmente con panel de logs/changelog en el lado izquierdo
  y la lista de versiones a la derecha.
- Al seleccionar una versión, el panel izquierdo muestra la descripción / logs
  asociados (toma la tercera columna si existe). Si la descripción contiene
  saltos de línea, se muestran tal cual.
- Binding corregido ("<<ListboxSelect>>").
- Eliminada la duplicación de la función apply_update y corregidos errores de
  strings con saltos de línea que provocaban SyntaxError.
"""

import os
import sys
import re
import threading
import time
import shutil
import zipfile
import subprocess
from pathlib import Path
from urllib.parse import urlparse, parse_qs

import requests
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

# ================= CONFIG =================
PASTEBIN_URL = "https://pastebin.com/raw/253RbBf9"  # formato: version | zip_url | descripcion (descripcion opcional)
APP_NAME = "TurboWarp Launcher"

# =========================================
# -------- PATHS (UNA SOLA BASE) ----------
if hasattr(sys, "_MEIPASS"):
    BASE = Path(sys._MEIPASS)
elif getattr(sys, "frozen", False):
    BASE = Path(sys.executable).parent
else:
    BASE = Path(__file__).parent.resolve()

WRITE_BASE = Path(sys.executable).parent if getattr(sys, "frozen", False) else BASE
VERL = WRITE_BASE / "verl.txt"
VERX = WRITE_BASE / "verx.txt"
VERSIONS = WRITE_BASE / "versions"
TEMP = WRITE_BASE / "temp"
SUSPENDED = WRITE_BASE / "suspended"
TURBOPATH = WRITE_BASE / "turbowarp_path.txt"

VERSIONS.mkdir(parents=True, exist_ok=True)
TEMP.mkdir(parents=True, exist_ok=True)
SUSPENDED.mkdir(parents=True, exist_ok=True)


def ensure_file(p: Path, default=""):
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text(default, encoding="utf-8")


ensure_file(VERL, "0.0.0")
ensure_file(VERX, "")
ensure_file(TURBOPATH, "")

# ---------- THEME COLORS (dark) ----------
COL_BG = "#0b0b0b"
COL_FRAME = "#111213"
COL_FG = "#e6e6e6"
COL_ACCENT = "#3aff7a"
COL_BTN = "#1f1f1f"
COL_ENTRY = "#0f1112"
COL_SELECT = "#334e3a"

# ---------- UTILS ----------


def read_verl():
    ensure_file(VERL, "0.0.0")
    return VERL.read_text().strip()


def write_verl(v: str):
    ensure_file(VERL)
    VERL.write_text(v, encoding="utf-8")


def normalize_paste(url: str) -> str:
    if "pastebin.com" in url and "/raw/" not in url:
        key = urlparse(url).path.strip("/")
        return f"https://pastebin.com/raw/{key}"
    return url


def parse_paste(txt: str):
    # devuelve la PRIMERA línea con formato válida: name | url | description?
    for l in txt.splitlines():
        s = l.strip()
        if not s:
            continue
        if "|" in s:
            parts = [p.strip() for p in s.split("|")]
            # admitimos: name | url o name | url | description
            if len(parts) >= 2:
                name = parts[0]
                url = parts[1]
                desc = parts[2] if len(parts) >= 3 else ""
                return name, url, desc
    raise ValueError("Formato inválido en pastebin")


def sanitize_filename(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", name)


# ---------- URL RESOLVE ----------


def resolve_mediafire(url: str) -> str:
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    m = re.search(r'https?://download[^"\']+', r.text)
    if not m:
        raise Exception("MediaFire no resolvió link directo")
    return m.group(0)


def resolve_gdrive(url: str) -> str:
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)
    fid = qs.get("id", [None])[0]
    if not fid:
        m = re.search(r"/file/d/([a-zA-Z0-9_-]+)", url)
        if m:
            fid = m.group(1)
    if not fid:
        raise Exception("No se pudo extraer ID de Google Drive.")
    return f"https://drive.google.com/uc?export=download&id={fid}"


def resolve_url(url: str) -> str:
    u = url.lower()
    if "mediafire.com" in u:
        return resolve_mediafire(url)
    if "drive.google.com" in u or "docs.google.com" in u:
        return resolve_gdrive(url)
    return url


# ---------- UPDATE APPLY (descarga, extrae, instala) ----------


def apply_update(zip_url: str, new_version: str, gui):
    gui.set_status("Descargando actualización...")
    zip_path = TEMP / "update.zip"

    try:
        direct = resolve_url(zip_url)
    except Exception as e:
        gui.set_status("Error resolviendo enlace")
        gui.schedule_messagebox_error("Error", f"No se pudo resolver enlace: {e}")
        return

    # descarga con progreso
    try:
        with requests.get(direct, stream=True, timeout=30) as r:
            r.raise_for_status()
            total_hdr = r.headers.get("content-length")
            total = int(total_hdr) if total_hdr and total_hdr.isdigit() else 0
            downloaded = 0
            if zip_path.exists():
                try:
                    zip_path.unlink()
                except Exception:
                    pass
            with open(zip_path, "wb") as f:
                for chunk in r.iter_content(8192):
                    if not chunk:
                        continue
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        perc = int(downloaded * 100 / total)
                        gui.update_progress(perc)
                        gui.set_status(
                            f"Descargando...\n{perc}% ({downloaded}/{total} bytes)"
                        )
                    else:
                        gui.progress_start()
                        gui.set_status(f"Descargando...\n{downloaded} bytes")
            gui.progress_stop()
    except Exception as e:
        gui.progress_stop()
        gui.set_status(f"Error en descarga: {e}")
        gui.schedule_messagebox_error("Error", f"No se pudo descargar: {e}")
        try:
            if zip_path.exists():
                zip_path.unlink()
        except Exception:
            pass
        return

    gui.set_status("Extrayendo actualización...")
    ext = TEMP / "ext"
    try:
        if ext.exists():
            shutil.rmtree(ext)
        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(ext)
    except Exception as e:
        gui.set_status(f"Error extrayendo: {e}")
        gui.schedule_messagebox_error("Error", f"No se pudo extraer el zip: {e}")
        try:
            if zip_path.exists():
                zip_path.unlink()
        except Exception:
            pass
        return
    finally:
        try:
            if zip_path.exists():
                zip_path.unlink()
        except Exception:
            pass

    gui.set_status("Instalando archivos (ignorando build/dist)...")
    exe_name = (
        Path(sys.executable).name
        if getattr(sys, "frozen", False)
        else Path(__file__).name
    )

    try:
        for root, dirs, files in os.walk(ext):
            # NO copiar carpetas típicas de build/update
            dirs[:] = [
                d for d in dirs if d.lower() not in ("build", "dist", "__pycache__")
            ]
            root = Path(root)
            for f in files:
                src = root / f
                rel = src.relative_to(ext)
                # bloquear rutas no deseadas
                if any(p.lower() in ("build", "dist") for p in rel.parts):
                    continue
                dst = WRITE_BASE / rel
                if getattr(sys, "frozen", False) and f == exe_name:
                    dst = WRITE_BASE / (exe_name + ".new")
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)

        write_verl(new_version)
        gui.set_status("Actualización aplicada correctamente.")
        gui.root.after(
            0,
            lambda: messagebox.showinfo(
                "Actualizado",
                f"Versión {new_version} instalada. Reinicia si es necesario.",
            ),
        )
    except Exception as e:
        gui.set_status(f"Error instalando: {e}")
        gui.schedule_messagebox_error("Error", f"Fallo durante la instalación: {e}")
    finally:
        try:
            if ext.exists():
                shutil.rmtree(ext)
        except Exception:
            pass


# ---------- THEME / GUI HELPERS ----------


def apply_dark_theme(root):
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass
    style.configure("TFrame", background=COL_FRAME)
    style.configure(
        "TLabel", background=COL_FRAME, foreground=COL_FG, font=("Segoe UI", 10)
    )
    style.configure(
        "Header.TLabel",
        font=("Segoe UI", 14, "bold"),
        foreground=COL_FG,
        background=COL_FRAME,
    )
    style.configure(
        "TButton", background=COL_BTN, foreground=COL_FG, relief="flat", padding=6
    )
    style.map("TButton", background=[("active", "#2a2a2a"), ("!disabled", COL_BTN)])
    style.configure("TEntry", fieldbackground=COL_ENTRY, foreground=COL_FG)
    style.configure(
        "Horizontal.TProgressbar", troughcolor=COL_FRAME, background=COL_ACCENT
    )
    root.configure(bg=COL_BG)


# ---------- LAUNCHER APP ----------


class LauncherApp:
    def __init__(self, root):
        self.root = root
        root.title(APP_NAME)
        root.geometry("760x520")
        root.resizable(False, False)
        apply_dark_theme(root)

        main = ttk.Frame(root, padding=12)
        main.pack(fill="both", expand=True)
        ttk.Label(main, text=APP_NAME, style="Header.TLabel").pack(anchor="w")

        top_frame = ttk.Frame(main)
        top_frame.pack(fill="both", expand=True, pady=(8, 6))

        # --- Paned window: logs (izquierda) | versiones (derecha)
        paned = ttk.PanedWindow(top_frame, orient=tk.HORIZONTAL)
        paned.pack(fill="both", expand=True)

        # panel izquierdo: Logs / Changelog (angosto)
        logs_frame = ttk.Frame(paned, width=300)
        logs_frame.pack_propagate(False)
        paned.add(logs_frame, weight=1)

        ttk.Label(logs_frame, text="Logs / Changelog", style="Header.TLabel").pack(
            anchor="w", padx=6, pady=(6, 2)
        )

        logs_text_frame = tk.Frame(logs_frame, bg=COL_FRAME)
        logs_text_frame.pack(fill="both", expand=True, padx=6, pady=4)

        self.logs_text = tk.Text(
            logs_text_frame,
            wrap="word",
            bg=COL_ENTRY,
            fg=COL_FG,
            insertbackground=COL_FG,
            state="disabled",
            bd=0,
            highlightthickness=0,
            font=("Segoe UI", 10),
        )
        self.logs_text.pack(side="left", fill="both", expand=True)

        logs_scroll = ttk.Scrollbar(
            logs_text_frame, orient="vertical", command=self.logs_text.yview
        )
        logs_scroll.pack(side="right", fill="y")
        self.logs_text.config(yscrollcommand=logs_scroll.set)

        # panel derecho: lista de versiones
        versions_frame = ttk.Frame(paned)
        paned.add(versions_frame, weight=3)

        ttk.Label(versions_frame, text="Versiones disponibles").pack(
            anchor="w", padx=6, pady=(6, 2)
        )

        lb_frame = tk.Frame(versions_frame, bg=COL_FRAME)
        lb_frame.pack(fill="both", expand=True)

        self.listbox = tk.Listbox(
            lb_frame,
            bg=COL_ENTRY,
            fg=COL_FG,
            selectbackground=COL_SELECT,
            selectforeground=COL_FG,
            bd=0,
            highlightthickness=0,
            font=("Segoe UI", 10),
        )
        self.listbox.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(
            lb_frame, orient="vertical", command=self.listbox.yview
        )
        scrollbar.pack(side="right", fill="y")
        self.listbox.config(yscrollcommand=scrollbar.set)

        # corregido binding
        self.listbox.bind("<<ListboxSelect>>", lambda e: self.on_select())

        self.progress = ttk.Progressbar(
            main, length=720, style="Horizontal.TProgressbar"
        )
        self.progress.pack(pady=(10, 6))

        self.status_label = ttk.Label(main, text="Listo.")
        self.status_label.pack(anchor="w")

        btn_frame = ttk.Frame(main)
        btn_frame.pack(fill="x", pady=(8, 0))

        ttk.Button(btn_frame, text="Descargar", command=self.on_download).pack(
            side="left", padx=6
        )
        ttk.Button(btn_frame, text="Lanzar", command=self.on_launch).pack(
            side="left", padx=6
        )
        ttk.Button(btn_frame, text="Eliminar local", command=self.on_delete).pack(
            side="left", padx=6
        )
        ttk.Button(btn_frame, text="Config TurboWarp", command=self.on_config).pack(
            side="left", padx=6
        )
        ttk.Button(
            btn_frame, text="Suspender / Reanudar", command=self.on_suspend_panel
        ).pack(side="left", padx=6)
        ttk.Button(
            btn_frame,
            text="Forzar check update",
            command=lambda: threading.Thread(
                target=self.check_update, daemon=True
            ).start(),
        ).pack(side="right", padx=6)

        # ya no usamos desc_label; el panel izquierdo muestra la descripción/logs
        self.versions = []  # list of tuples (name, url, desc)
        self._download_lock = threading.Lock()

        self.reload_versions()

        # check updates en background
        threading.Thread(target=self.check_update, daemon=True).start()

    # ---------- thread-safe UI helpers ----------
    def _call_on_main(self, func, *args, **kwargs):
        self.root.after(0, lambda: func(*args, **kwargs))

    def set_status(self, text: str):
        def _update():
            try:
                self.status_label.config(text=text)
                self.root.update_idletasks()
            except Exception:
                pass

        self._call_on_main(_update)

    def update_progress(self, value: int):
        def _update():
            try:
                self.progress["value"] = value
                self.root.update_idletasks()
            except Exception:
                pass

        self._call_on_main(_update)

    def progress_start(self, interval=10):
        def _start():
            try:
                self.progress.start(interval)
                self.root.update_idletasks()
            except Exception:
                pass

        self._call_on_main(_start)

    def progress_stop(self):
        def _stop():
            try:
                self.progress.stop()
                self.root.update_idletasks()
            except Exception:
                pass

        self._call_on_main(_stop)

    def schedule_messagebox_error(self, title, msg):
        def _show():
            messagebox.showerror(title, msg)

        self._call_on_main(_show)

    # ---------- versiones / UI ----------
    def reload_versions(self):
        """Carga versiones desde VERX.

        - Soporta logs multilínea: Si la tercera columna está vacía o no termina en ';',
          se tomarán las siguientes líneas como parte del log hasta encontrar una línea
          que termine en ';' (el ';' final se elimina).

        Formato soportado (ejemplos):

        1) Línea simple (todo en una línea):
           name | url | descripción corta;

        2) Línea + bloque de logs:
           name | url |
           línea del log 1
           línea del log 2
           línea final del log ;

        Notas:
        - El punto y coma final ";" marca el final del bloque de logs.
        - Si no hay descripción ni bloque, el log quedará vacío.
        """
        self.versions = []

        def _do():
            self.listbox.delete(0, tk.END)
            # limpiar panel de logs
            self._call_on_main(lambda: self._set_logs_text(""))

            if not VERX.exists():
                self.set_status("verx.txt no encontrado.")
                return

            raw = VERX.read_text(encoding="utf-8").splitlines()
            i = 0
            while i < len(raw):
                line = raw[i].rstrip("\n")
                s = line.strip()
                if not s:
                    i += 1
                    continue
                if "|" in s:
                    parts = [p.strip() for p in s.split("|")]
                    name = parts[0]
                    url = parts[1] if len(parts) >= 2 else ""
                    desc = parts[2] if len(parts) >= 3 else ""

                    # Si la descripción termina en ';' entonces es completa en la misma línea
                    if desc.endswith(";"):
                        desc = desc[:-1].strip()
                    else:
                        # si no termina con ;, recopilamos líneas siguientes hasta encontrar una que lo haga
                        collected = []
                        j = i + 1
                        while j < len(raw):
                            nxt = raw[j]
                            if nxt.strip() == "":
                                j += 1
                                continue
                            if nxt.rstrip().endswith(";"):
                                # línea final del bloque (quitamos el ;)
                                collected.append(nxt.rstrip()[:-1])
                                j += 1
                                break
                            else:
                                collected.append(nxt)
                                j += 1
                        if collected:
                            if desc:
                                desc = (desc + "\n" + "\n".join(collected)).strip()
                            else:
                                desc = "\n".join(collected).strip()
                            # avanzamos el índice hasta la línea consumida
                            i = j - 1

                    mark = (
                        "✓"
                        if (VERSIONS / (sanitize_filename(name) + ".sb3")).exists()
                        else " "
                    )
                    self.versions.append((name, url, desc))
                    display = f"[{mark}] {name}"
                    self.listbox.insert(tk.END, display)
                i += 1

            self.set_status("Lista recargada.")

        self._call_on_main(_do)

    def get_selected(self):
        sel = self.listbox.curselection()
        if not sel:
            return None
        idx = sel[0]
        if idx < 0 or idx >= len(self.versions):
            return None
        return self.versions[idx]

    def _set_logs_text(self, text: str):
        try:
            self.logs_text.config(state="normal")
            self.logs_text.delete("1.0", "end")
            self.logs_text.insert("end", text)
            self.logs_text.config(state="disabled")
        except Exception:
            pass

    def on_select(self):
        sel = self.get_selected()
        if not sel:
            self.set_status("Seleccione una versión.")
            self._call_on_main(lambda: self._set_logs_text(""))
            return
        name, url, desc = sel
        p = VERSIONS / (sanitize_filename(name) + ".sb3")
        if p.exists():
            self.set_status(f"{name} -> listo localmente ({p.name})")
        else:
            self.set_status(f"{name} -> no descargado")

        # show description / logs in the left panel
        logs_text = desc or "(sin descripción)"
        logs_text += f"\n\nURL: {url}"
        self._call_on_main(lambda: self._set_logs_text(logs_text))

    # ---------- descarga ----------
    def on_download(self):
        sel = self.get_selected()
        if not sel:
            self.schedule_messagebox_error("Info", "Selecciona una versión primero.")
            return
        threading.Thread(target=self._download_thread, args=(sel,), daemon=True).start()

    def _download_thread(self, sel):
        with self._download_lock:
            name, url, _ = sel
            tmp = VERSIONS / (sanitize_filename(name) + ".sb3.part")
            final = VERSIONS / (sanitize_filename(name) + ".sb3")
            if tmp.exists():
                try:
                    tmp.unlink()
                except Exception:
                    pass
            session = requests.Session()
            try:
                self.set_status(f"Resolviendo enlace para {name}...")
                resolved = resolve_url(url)
            except Exception as e:
                self.set_status("Error resolviendo enlace")
                self.schedule_messagebox_error(
                    "Error", f"No se pudo resolver enlace: {e}"
                )
                return

            try:
                self.set_status(f"Descargando {name}...")
                with session.get(
                    resolved, stream=True, allow_redirects=True, timeout=30
                ) as r:
                    r.raise_for_status()
                    total_hdr = r.headers.get("content-length")
                    total = int(total_hdr) if total_hdr and total_hdr.isdigit() else 0
                    downloaded = 0
                    with open(tmp, "wb") as f:
                        for chunk in r.iter_content(8192):
                            if not chunk:
                                continue
                            f.write(chunk)
                            downloaded += len(chunk)
                            if total:
                                perc = int(downloaded * 100 / total)
                                self.update_progress(perc)
                                self.set_status(
                                    f"Descargando {name}: {perc}% ({downloaded}/{total} bytes)"
                                )
                            else:
                                self.progress_start()
                                self.set_status(
                                    f"Descargando {name}: {downloaded} bytes"
                                )
                self.progress_stop()

                if not zipfile.is_zipfile(tmp):
                    raise Exception("Archivo inválido (no es ZIP/SB3 válido).")
                if final.exists():
                    final.unlink()
                tmp.rename(final)
                self.set_status(f"Descargado: {final.name}")
                self.reload_versions()
            except Exception as e:
                self.progress_stop()
                self.set_status(f"Error en descarga: {e}")
                self.schedule_messagebox_error("Error", f"No se pudo descargar: {e}")

    # ---------- eliminar ----------
    def on_delete(self):
        sel = self.get_selected()
        if not sel:
            self.schedule_messagebox_error("Info", "Selecciona una versión primero.")
            return
        name, _, _ = sel
        p = VERSIONS / (sanitize_filename(name) + ".sb3")
        if not p.exists():
            self.schedule_messagebox_error("Info", "No existe el archivo local.")
            self.reload_versions()
            return

        def _confirm_and_delete():
            if not messagebox.askyesno("Confirm", f"Eliminar {p.name}?"):
                return
            try:
                p.unlink()
                self.set_status(f"{p.name} eliminado.")
                self.reload_versions()
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo eliminar: {e}")

        self._call_on_main(_confirm_and_delete)

    # ---------- config ----------
    def on_config(self):
        cur = (
            TURBOPATH.read_text(encoding="utf-8").strip() if TURBOPATH.exists() else ""
        )

        def _do_config():
            if messagebox.askyesno(
                "Config TurboWarp",
                "¿Seleccionar archivo TurboWarp.exe manualmente?",
            ):
                path = filedialog.askopenfilename(
                    title="Selecciona TurboWarp.exe",
                    filetypes=[("Executables", "*.exe"), ("All files", "*.*")],
                )
                if path:
                    TURBOPATH.write_text(path, encoding="utf-8")
                    messagebox.showinfo("Guardado", f"Ruta guardada: {path}")
            else:
                if cur and messagebox.askyesno(
                    "Eliminar", "¿Eliminar la ruta guardada actual?"
                ):
                    try:
                        TURBOPATH.unlink(missing_ok=True)
                        messagebox.showinfo("Eliminado", "Ruta guardada eliminada.")
                    except Exception:
                        pass

        self._call_on_main(_do_config)

    # ---------- launch ----------
    def on_launch(self):
        sel = self.get_selected()
        if not sel:
            self.schedule_messagebox_error("Info", "Selecciona una versión primero.")
            return
        name, _, _ = sel
        p = VERSIONS / (sanitize_filename(name) + ".sb3")
        if not p.exists():

            def _ask_dl():
                if messagebox.askyesno(
                    "No descargado", "El archivo no está descargado.\n¿Descargar ahora?"
                ):
                    self.on_download()

            self._call_on_main(_ask_dl)
            return

        turbo = (
            TURBOPATH.read_text(encoding="utf-8").strip()
            if TURBOPATH.exists()
            else None
        )
        if turbo and Path(turbo).exists():
            try:
                subprocess.Popen([turbo, str(p)], cwd=str(WRITE_BASE))
                return
            except Exception:
                pass
        try:
            if sys.platform.startswith("win"):
                os.startfile(p)
            elif sys.platform.startswith("darwin"):
                subprocess.Popen(["open", str(p)])
            else:
                subprocess.Popen(["xdg-open", str(p)])
        except Exception:
            self.schedule_messagebox_error(
                "Error",
                "No se pudo abrir automáticamente.\nConfigura TurboWarp en 'Config TurboWarp'.",
            )

    # ---------- SUSPENDER / REANUDAR UI ----------
    def on_suspend_panel(self):
        sel = self.get_selected()
        if not sel:
            self.schedule_messagebox_error("Info", "Selecciona una versión primero.")
            return
        name, _, _ = sel
        src = VERSIONS / (sanitize_filename(name) + ".sb3")
        suspended_name = sanitize_filename(name) + ".suspend.zip"
        suspended_path = SUSPENDED / suspended_name

        def _open_panel():
            w = tk.Toplevel(self.root)
            w.title(f"Suspender / Reanudar: {name}")
            w.geometry("520x240")
            apply_dark_theme(w)
            ttk.Label(w, text=f"Versión: {name}", style="Header.TLabel").pack(
                anchor="w", padx=8, pady=(8, 2)
            )
            ttk.Label(w, text=f"Archivo origen: {src.name}").pack(anchor="w", padx=8)

            # Compression presets
            presets = [
                "Store (no comp)",
                "Fast (deflate)",
                "Balanced (deflate)",
                "High (bzip2)",
                "Max (lzma)",
            ]
            preset_var = tk.StringVar(value=presets[2])
            ttk.Label(w, text="Preset de compresión:").pack(
                anchor="w", padx=8, pady=(10, 0)
            )
            preset_cb = ttk.Combobox(
                w, values=presets, textvariable=preset_var, state="readonly"
            )
            preset_cb.pack(fill="x", padx=8)

            out_entry = ttk.Entry(w)
            out_entry.insert(0, suspended_path.name)
            out_entry.pack(fill="x", padx=8, pady=(8, 0))

            status = ttk.Label(w, text="Listo.")
            status.pack(anchor="w", padx=8, pady=(8, 0))

            def set_status_local(t):
                status.config(text=t)

            def do_suspend():
                if not src.exists():
                    messagebox.showerror("Error", "Archivo origen no existe.")
                    return
                outname = out_entry.get().strip()
                if not outname:
                    messagebox.showerror("Error", "Nombre de salida inválido.")
                    return
                target = SUSPENDED / outname
                if target.exists() and not messagebox.askyesno(
                    "Sobrescribir", "El archivo ya existe.\nSobrescribir?"
                ):
                    return
                choice = preset_var.get()
                threading.Thread(
                    target=self._compress_file_thread,
                    args=(src, target, choice, set_status_local),
                    daemon=True,
                ).start()

            def do_resume():
                if not suspended_path.exists():
                    messagebox.showerror(
                        "Error",
                        "No existe un archivo suspendido con el nombre por defecto. Selecciona el archivo suspendido.",
                    )
                    return
                dest = VERSIONS / src.name
                if dest.exists() and not messagebox.askyesno(
                    "Sobrescribir", f"{dest.name} existe.\nSobrescribir?"
                ):
                    return
                threading.Thread(
                    target=self._decompress_file_thread,
                    args=(suspended_path, dest, set_status_local),
                    daemon=True,
                ).start()

            btn_frame = ttk.Frame(w)
            btn_frame.pack(fill="x", pady=8, padx=8)
            ttk.Button(
                btn_frame, text="Suspender (comprimir)", command=do_suspend
            ).pack(side="left", padx=6)
            ttk.Button(
                btn_frame, text="Reanudar (descomprimir)", command=do_resume
            ).pack(side="left", padx=6)

        self._call_on_main(_open_panel)

    def _compress_file_thread(self, src: Path, target: Path, preset: str, status_cb):
        try:
            status_cb("Preparando compresión...")
            # map preset to compress_type and compresslevel
            if preset.startswith("Store"):
                ctype = zipfile.ZIP_STORED
                clevel = None
            elif preset.startswith("Fast"):
                ctype = zipfile.ZIP_DEFLATED
                clevel = 1
            elif preset.startswith("Balanced"):
                ctype = zipfile.ZIP_DEFLATED
                clevel = 6
            elif preset.startswith("High"):
                ctype = zipfile.ZIP_BZIP2
                clevel = None
            else:
                ctype = zipfile.ZIP_LZMA
                clevel = None

            total = src.stat().st_size
            processed = 0

            try:
                if clevel is not None:
                    zf = zipfile.ZipFile(
                        target, "w", compression=ctype, compresslevel=clevel
                    )
                else:
                    zf = zipfile.ZipFile(target, "w", compression=ctype)
            except TypeError:
                zf = zipfile.ZipFile(target, "w", compression=ctype)

            with zf:
                arcname = src.name
                try:
                    dest = zf.open(arcname, "w")
                except Exception as e:
                    status_cb(f"Error creando zip: {e}")
                    try:
                        if target.exists():
                            target.unlink()
                    except Exception:
                        pass
                    return

                with dest:
                    with open(src, "rb") as sf:
                        while True:
                            chunk = sf.read(1024 * 64)
                            if not chunk:
                                break
                            dest.write(chunk)
                            processed += len(chunk)
                            perc = int(processed * 100 / total) if total else 0
                            status_cb(f"Comprimiendo...\n{perc}%")
                            self.update_progress(perc)

            status_cb(f"Listo: {target.name}")
            self.update_progress(0)
        except Exception as e:
            status_cb(f"Error compresión: {e}")
            try:
                if target.exists():
                    target.unlink()
            except Exception:
                pass

    def _decompress_file_thread(self, src: Path, dest: Path, status_cb):
        try:
            status_cb("Preparando descompresión...")
            with zipfile.ZipFile(src, "r") as zf:
                namelist = zf.namelist()
                if not namelist:
                    status_cb("Zip vacío")
                    return
                entry = namelist[0]
                info = zf.getinfo(entry)
                total = info.file_size if hasattr(info, "file_size") else 0
                processed = 0
                with zf.open(entry, "r") as rf:
                    with open(dest, "wb") as outf:
                        while True:
                            chunk = rf.read(1024 * 64)
                            if not chunk:
                                break
                            outf.write(chunk)
                            processed += len(chunk)
                            perc = int(processed * 100 / total) if total else 0
                            status_cb(f"Descomprimiendo...\n{perc}%")
                            self.update_progress(perc)

            status_cb(f"Reanudad: {dest.name}")
            self.update_progress(0)
            self.reload_versions()
        except Exception as e:
            status_cb(f"Error descompresión: {e}")
            try:
                if dest.exists():
                    dest.unlink()
            except Exception:
                pass

    # ---------- UPDATE CHECK ----------
    def check_update(self):
        try:
            local = read_verl()
            txt = requests.get(normalize_paste(PASTEBIN_URL), timeout=10).text
            remote, url, _ = parse_paste(txt)
            if remote != local:

                def _ask_and_apply():
                    if messagebox.askyesno(
                        "Actualización disponible",
                        f"Hay nueva versión: {local} → {remote}\n¿Descargar e instalar?",
                    ):
                        threading.Thread(
                            target=apply_update, args=(url, remote, self), daemon=True
                        ).start()

                self._call_on_main(_ask_and_apply)
            else:
                self.set_status("No hay actualizaciones.")
        except Exception as e:
            self.set_status(f"Error check update: {e}")


# ---------- BOOT / SWAP .new exe ----------


def swap_new_exe_if_present():
    if getattr(sys, "frozen", False):
        exe = Path(sys.executable)
        new = exe.with_name(exe.name + ".new")
        try:
            if new.exists():
                try:
                    exe.unlink()
                except Exception:
                    time.sleep(0.4)
                try:
                    new.rename(exe)
                except Exception:
                    pass
        except Exception:
            pass


# ---------- MAIN ----------


def main():
    swap_new_exe_if_present()
    root = tk.Tk()
    app = LauncherApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
